package com.lenovo.lewea;

public final class R
{
  public static final class drawable
  {
  	public static final int lenweather_widget_bg_cloudy = 2130838166;
    public static final int lenweather_widget_colon = 2130838186;
    public static final int week_bg = 2130838410;
    public static final int lenweather_widget_icon_cloudy = 2130838192;
  }

  public static final class id
  {
  	public static final int widget_bg_2 = 2131296283;
  	public static final int bg_widget = 2131296259;
  	public static final int widgetTimeLayout = 2131296277;
    public static final int widgetHour01Image = 2131296273;
    public static final int widgetHour02Image = 2131296274;
    public static final int widgetColonImage = 2131296271;
    public static final int widgetMinute01Image = 2131296275;
    public static final int widgetMinute02Image = 2131296276;
    public static final int widgetDateText = 2131296272;
    public static final int widgetWeekText = 2131296280;
    public static final int widgetAPMImage = 2131296269;
    public static final int widgetWeatherLayout = 2131296278;
    public static final int widgetCityNameText = 2131296270;
    public static final int widgetWeatherText = 2131296279;
    public static final int weather_img = 2131296268;
    public static final int llTemperature = 2131296262;
    public static final int temperature_max = 2131296263;
    public static final int temperature_min = 2131296264;
    public static final int temperature_unit = 2131296266;                                              	
  }

  public static final class layout
  {
    public static final int weather_widget_provider = 2130903094;
  }
}